var searchData=
[
  ['setx',['setX',['../class_point.html#a428a1676e2fdec6753c42011a1d59d18',1,'Point']]],
  ['setxy',['setXY',['../class_point.html#ab5385c6d9bfa841e641e4709fc9f14cc',1,'Point']]],
  ['sety',['setY',['../class_point.html#a9868c4601b0ea0c2d0de20fe41ee0e49',1,'Point']]],
  ['sub',['sub',['../class_point.html#a5df49407ad8201f8df50595cdaa51965',1,'Point']]]
];
