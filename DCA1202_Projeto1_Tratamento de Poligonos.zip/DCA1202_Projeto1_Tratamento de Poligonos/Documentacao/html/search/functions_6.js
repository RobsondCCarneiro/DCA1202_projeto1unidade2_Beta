var searchData=
[
  ['poligono',['Poligono',['../class_poligono.html#a9311a9a1496878c09c8508b3636e2870',1,'Poligono']]]
];
