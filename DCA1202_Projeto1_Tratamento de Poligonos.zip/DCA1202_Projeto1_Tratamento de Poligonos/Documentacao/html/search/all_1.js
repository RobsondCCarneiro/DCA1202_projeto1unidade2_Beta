var searchData=
[
  ['centromassa',['CentroMassa',['../class_poligono.html#a4a9655dc1b51111a10fed88c536eb676',1,'Poligono']]]
];
