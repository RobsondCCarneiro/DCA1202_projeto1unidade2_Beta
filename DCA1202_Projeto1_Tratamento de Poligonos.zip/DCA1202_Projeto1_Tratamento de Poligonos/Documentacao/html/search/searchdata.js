var indexSectionsWithContent =
{
  0: "acgimnpqrst",
  1: "pr",
  2: "mpr",
  3: "acgimnpqrst",
  4: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "defines"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Classes",
  2: "Arquivos",
  3: "Funções",
  4: "Definições e Macros"
};

