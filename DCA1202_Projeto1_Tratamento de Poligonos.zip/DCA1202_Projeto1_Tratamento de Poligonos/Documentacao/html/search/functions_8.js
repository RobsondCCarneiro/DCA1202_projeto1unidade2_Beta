var searchData=
[
  ['retangulo',['Retangulo',['../class_retangulo.html#a63298e7539b365e7c71fe1a1fe672cf1',1,'Retangulo']]],
  ['rotacionapoligono',['rotacionaPoligono',['../class_poligono.html#ad6448a824a4f3bc820db4b81102b2230',1,'Poligono']]]
];
